//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "FtpTst2.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TDirectoryForm *DirectoryForm;
//---------------------------------------------------------------------------
__fastcall TDirectoryForm::TDirectoryForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------