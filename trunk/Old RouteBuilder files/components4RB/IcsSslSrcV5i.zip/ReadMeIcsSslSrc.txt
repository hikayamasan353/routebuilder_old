ICS-SSL COMPONENTS AND DEMOS (PRE-RELEASE)
==========================================


* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*                                                                         *
*              THIS IS NOT FREEWARE NOR OPEN SOURCE SOFTWARE              *
*                DO NOT DISTRIBUTE OR SHARE IT WITH OTHERS                *
*      YOU MUST FINANCIALLY CONTRIBUTE TO THE ICS-SSL EFFORT TO USE IT    *
*                                                                         *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *


LEGAL ISSUES:
-------------
Copyright (C) 2003-2005 by Fran�ois PIETTE
Rue de Grady 24, 4053 Embourg, Belgium. Fax: +32-4-365.74.56
mailto:francois.piette@overbyte.be
http://www.overbyte.be

SSL implementation includes code written by Arno Garrels,
Berlin, Germany, contact: <arno.garrels@gmx.de>

This software is provided 'as-is', without any express or
implied warranty.  In no event will the author be held liable
for any  damages arising from the use of this software.

This code is _NOT_ freeware nor Open Source.
To use it, you must financially contribute to the development.
See SSL page at http://www.overbyte.be for details.

Once you got the right to use this software, you can use in your
own applications only. Distributing the source code or compiled
units or packages is prohibed.

As this code make use of OpenSSL, your rights are restricted by
OpenSSL license. See http://www.openssl.org for details.

Further, the following restrictions applies:

1. The origin of this software must not be misrepresented,
   you must not claim that you wrote the original software.
   If you use this software in a product, an acknowledgment
   in the product documentation would be appreciated but is
   not required.

2. Altered source versions must be plainly marked as such, and
   must not be misrepresented as being the original software.

3. This notice may not be removed or altered from any source
   distribution.

4. You must register this software by sending a picture postcard
   to the author. Use a nice stamp and mention your name, street
   address, EMail address and any comment you like to say.


CERTIFICATES:
-------------

To make use of SSL, you need certificate. I provide some demo
certificate I built using command line OpenSSL tool.

CACERT.PEM :   A demo certificate for "Example CA" 
01CERT.PEM :   A demo certificate which is signed by CACERT.PEM
01KEY.PEM :    A demo private key for 01CERT.PEM
               Passphrase is "password".
CLIENT.PEM :   A demo certificate and private key.
               Passphrase is "password".
SERVER.PEM :   A demo certificate and private key.
               Passphrase is "password".
ROOT.PEM :     A demo CA certificate.
               Passphrase is "password".

For details about certificate, see the book:
  "Network security with OpenSSL", O'Reilly

INSTALLATION:
-------------

This is pre-release software. Backup your disk before using it !

Unzip the archive in the same directory where you installed ICS, restoring the
directory tree present in the zip file. Replace ICS files with the files you
find with this package (Other ICS components will continue to work).

There is a project group file for Delphi 5, 6 and 7. In this project group,
you'll find a package you must first compile and install before opening the
sample programs. Altough not tested, the components and test programs should
work with all 32 bit Delphi versions with no or minor changes. It should also
works as well with all C++ Builder versions.

Note that TWSocket component is included in the ICS-SSL package. You may wants
to remove it either from the regular ICS package or from the ICS-SSL package to
avoid conflict.

To use the component, you must have LIBEAY32.DLL and SSLEAY32.DLL available
somewhere in your path. Your applications will not run if those DLL are not 
available on the target system. See http://www.openssl.org for instructions,
licensing and source code.

If you need help, please avoid mailing me directly. Instead, use the ICS-SSL
mailing list to ask for your questions. You can subscribe by pointing your
browser to http://www.elists.org/mailman/listinfo/ics-ssl


HOW TO USE:
-----------

TSslWSocket and TSslWSocketServer component are derived from the standard 
TWSocket and TWSocketServer component. The SSL code is compiled into the
component only if you define USE_SSL symbol to your packages and projects.
Just add USE_SSL to the defines in the project or package options and
recompile everything.

The components make use of LIBEAY32.DLL and SSLEAY32.DLL to handle SSL
protocol stuff. The DLL are dynamically loaded at runtime. It means that
the DLL will only be required at runtime when you first make use of a SSL
function. Your applications will run on system without OpenSSL DLL as long
as you don't call any SSL function.


Fran�ois PIETTE
mailto:francois.piette@overbyte.be
Revised: Oct 31, 2005
