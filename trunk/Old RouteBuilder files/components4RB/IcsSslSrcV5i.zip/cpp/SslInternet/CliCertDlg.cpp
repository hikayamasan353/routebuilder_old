//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "CliCertDlg.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TClientCertDlg *ClientCertDlg;
//---------------------------------------------------------------------------
__fastcall TClientCertDlg::TClientCertDlg(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
