//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MForm.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "LngINISupp"
#pragma link "MsgINISupp"
#pragma resource "*.dfm"
TMainForm *MainForm;
//---------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::FormShow(TObject *Sender)
{
  LIS->FileName = "English.lng";
  LIS->Open();        
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::FormClose(TObject *Sender, TCloseAction &Action)
{
  LIS->Close();        
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::Open1Click(TObject *Sender)
{
  if (OpenDialog1->Execute())
    {
    }
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Save1Click(TObject *Sender)
{
  if (SaveDialog1->Execute())
    {
    }
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::OpenPicture1Click(TObject *Sender)
{
  if (OpenPictureDialog1->Execute())
    {
    }
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SavePicture1Click(TObject *Sender)
{
  if (SavePictureDialog1->Execute())
    {
    }
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Exit1Click(TObject *Sender)
{
  Close();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Button2Click(TObject *Sender)
{
  Close();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Button3Click(TObject *Sender)
{
  MIS->Open();
  ShowMessage(MIS->GetMsg("Error1"));
  ShowMessage(MIS->GetMsg("Error1") + '\n' + MIS->GetMsg("Error1"));
  ShowMessage(Format(MIS->GetMsg("Error2"),ARRAYOFCONST((Edit2->Text, Edit3->Text, Edit4->Text, 25000))));
  MIS->Close();
}
//---------------------------------------------------------------------------

