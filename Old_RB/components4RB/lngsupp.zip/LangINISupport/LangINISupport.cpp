//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("LangINISupport.res");
USEPACKAGE("vcl50.bpi");
USEUNIT("LngINISupp.pas");
USEUNIT("MsgINISupp.pas");
USEPACKAGE("Tee50.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
