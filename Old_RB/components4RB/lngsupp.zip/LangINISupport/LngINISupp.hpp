// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'LngINISupp.pas' rev: 5.00

#ifndef LngINISuppHPP
#define LngINISuppHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Buttons.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <Chart.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <IniFiles.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Lnginisupp
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TLngINISupp;
class PASCALIMPLEMENTATION TLngINISupp : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	AnsiString FFileName;
	Menus::TMainMenu* FMenu;
	Menus::TPopupMenu* FPMenu;
	void __fastcall SetFileName(const AnsiString Value);
	void __fastcall CheckFile(AnsiString FN);
	void __fastcall FindCaptions(void);
	void __fastcall MenuOnClick(System::TObject* Sender);
	void __fastcall PMenuOnClick(System::TObject* Sender);
	void __fastcall ReadCaptions(void);
	void __fastcall FindLngFilesM(void);
	void __fastcall FindLngFilesP(void);
	void __fastcall VerifyValue(AnsiString FormName, AnsiString CompName, AnsiString CapLab);
	void __fastcall SetMenu(const Menus::TMainMenu* Value);
	void __fastcall SetPMenu(const Menus::TPopupMenu* Value);
	
public:
	void __fastcall Open(void);
	void __fastcall Close(void);
	void __fastcall Read(void);
	void __fastcall Save(void);
	
__published:
	__property AnsiString FileName = {read=FFileName, write=SetFileName};
	__property Menus::TMainMenu* Menu = {read=FMenu, write=SetMenu};
	__property Menus::TPopupMenu* PopupMenu = {read=FPMenu, write=SetPMenu};
public:
	#pragma option push -w-inl
	/* TComponent.Create */ inline __fastcall virtual TLngINISupp(Classes::TComponent* AOwner) : Classes::TComponent(
		AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TComponent.Destroy */ inline __fastcall virtual ~TLngINISupp(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE Inifiles::TIniFile* AppIni;
extern PACKAGE BOOL FNF;
extern PACKAGE BOOL FNP;
extern PACKAGE BOOL VV;
extern PACKAGE BOOL MC;
extern PACKAGE BOOL PC;
extern PACKAGE Classes::TStrings* LngFiles;
extern PACKAGE Menus::TMenuItem* Lng;
extern PACKAGE Menus::TMenuItem* Child;
extern PACKAGE Menus::TMenuItem* PLng;
extern PACKAGE Menus::TMenuItem* PChild;
extern PACKAGE BOOL Changed;
extern PACKAGE void __fastcall Register(void);

}	/* namespace Lnginisupp */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Lnginisupp;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// LngINISupp
